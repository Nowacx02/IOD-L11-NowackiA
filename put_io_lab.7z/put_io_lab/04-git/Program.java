
public class Main {
    public static void main(String[] args) {

        //zmienne string
        String a = "a";
        String b = " b";
        String c = " c";
        String d = " d";

        a = a + b + c + d;

        System.out.println(a); //wyswietlenie napisu
        System.out.println("Miłego Dnia życzę Panu");

    }
}